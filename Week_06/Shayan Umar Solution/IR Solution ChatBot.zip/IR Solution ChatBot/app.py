# # import os
# # import faiss
# # import numpy as np
# # import streamlit as st
# # from io import BytesIO
# # from PyPDF2 import PdfReader
# # from dotenv import load_dotenv
# # import json
# # import hashlib

# # from langchain_groq import ChatGroq
# # from langchain.prompts import PromptTemplate
# # from langchain_text_splitters import RecursiveCharacterTextSplitter
# # from langchain_community.embeddings import HuggingFaceEmbeddings

# # # Load API key from environment
# # load_dotenv()
# # groq_api_key = os.environ.get("GROQ_API_KEY")

# # # Directory to save processed data
# # DATA_DIR = "processed_data"
# # if not os.path.exists(DATA_DIR):
# #     os.makedirs(DATA_DIR)

# # # Hashing function for creating a unique identifier for each PDF
# # def get_pdf_hash(file_bytes):
# #     """Generates a unique hash for the PDF file content."""
# #     return hashlib.sha256(file_bytes).hexdigest()

# # # Function to save processed data to disk
# # def save_processed_data(pdf_hash, index, chunks):
# #     """Saves the FAISS index and chunks to the DATA_DIR."""
# #     index_file = os.path.join(DATA_DIR, f"{pdf_hash}.faiss")
# #     chunks_file = os.path.join(DATA_DIR, f"{pdf_hash}.json")
    
# #     faiss.write_index(index, index_file)
# #     with open(chunks_file, 'w') as f:
# #         json.dump(chunks, f)

# # # Function to load processed data from disk
# # def load_processed_data(pdf_hash):
# #     """Loads the FAISS index and chunks from the DATA_DIR if they exist."""
# #     index_file = os.path.join(DATA_DIR, f"{pdf_hash}.faiss")
# #     chunks_file = os.path.join(DATA_DIR, f"{pdf_hash}.json")

# #     if os.path.exists(index_file) and os.path.exists(chunks_file):
# #         st.write("Loading pre-processed data from disk...")
# #         index = faiss.read_index(index_file)
# #         with open(chunks_file, 'r') as f:
# #             chunks = json.load(f)
# #         return index, chunks
# #     return None, None

# # # Function to load and extract text from PDF
# # def load_pdf(uploaded_file_bytes):
# #     pdf_file = BytesIO(uploaded_file_bytes)
# #     reader = PdfReader(pdf_file)
# #     text = "".join([page.extract_text() for page in reader.pages])
# #     return text

# # # Function to process the PDF, split text, and create embeddings
# # def process_pdf(text):
# #     text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
# #     chunks = text_splitter.split_text(text)

# #     embedding_model = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
# #     embeddings = embedding_model.embed_documents(chunks)
    
# #     embedding_matrix = np.array(embeddings).astype("float32")
    
# #     dim = embedding_matrix.shape[1]
# #     index = faiss.IndexFlatL2(dim)
# #     index.add(embedding_matrix)
    
# #     return index, chunks

# # # Function to retrieve relevant chunks using FAISS
# # def faiss_retriever(question, index, chunks):
# #     embedding_model = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
# #     question_embedding = np.array([embedding_model.embed_query(question)]).astype("float32")
    
# #     _, indices = index.search(question_embedding, k=5)
# #     return [chunks[i] for i in indices[0]]

# # # Function to chat with PDF using Groq API
# # def chat_with_pdf(question, index, chunks, model):
# #     relevant_chunks = faiss_retriever(question, index, chunks)
# #     context = "\n\n".join(relevant_chunks)

# #     prompt_template = PromptTemplate.from_template("""
# #     You are a helpful assistant for question answering from documents.
# #     Only answer using the information provided in the context.
# #     If the answer is not explicitly contained in the context, respond with:
# #     "I could not find the answer in the provided document."

# #     Context:
# #     {context}

# #     Question: {question}
# #     """)

# #     prompt = prompt_template.format(context=context, question=question)
    
# #     chat_groq = ChatGroq(groq_api_key=groq_api_key, model_name=model)
# #     response = chat_groq.invoke(prompt)

# #     return response.content if hasattr(response, "content") else str(response)

# # # Streamlit UI
# # st.title("PDF Chatbot with Groq & FAISS")

# # uploaded_file = st.file_uploader("Upload a PDF", type="pdf")

# # if uploaded_file:
# #     uploaded_file_bytes = uploaded_file.read()
# #     pdf_hash = get_pdf_hash(uploaded_file_bytes)
    
# #     index, chunks = load_processed_data(pdf_hash)

# #     if index is None or chunks is None:
# #         st.write("Processing new PDF...")
# #         # Process the new PDF
# #         text = load_pdf(uploaded_file_bytes)
# #         index, chunks = process_pdf(text)
        
# #         # Save the processed data for future use
# #         save_processed_data(pdf_hash, index, chunks)
# #         st.write("PDF processed and saved! You can now ask questions.")

# #     else:
# #         st.write("PDF data loaded from disk. You can now ask questions.")

# #     # Main interaction logic
# #     model = st.sidebar.selectbox("Select Groq Model", ['qwen/qwen3-32b', 'gemma2-9b-it','llama-3.1-8b-instant'])
# #     question = st.text_input("Ask a question about the PDF:")

# #     if question:
# #         st.write("Fetching answer...")
# #         response = chat_with_pdf(question, index, chunks, model)
# #         st.write("Answer:", response)

# # else:
# #     st.write("Upload a PDF to begin!")


# import os
# import faiss
# import numpy as np
# import streamlit as st
# from io import BytesIO
# from PyPDF2 import PdfReader
# from dotenv import load_dotenv
# import json
# import hashlib
# from langchain_groq import ChatGroq
# from langchain.prompts import PromptTemplate
# from langchain_text_splitters import RecursiveCharacterTextSplitter
# from langchain_community.embeddings import HuggingFaceEmbeddings

# # ------------------ CONFIG ------------------ #
# PDF_PATH = "sample_docs/Team_Workflow_Responsbilities.pdf"  # Path to your PDF
# DATA_DIR = "processed_data"
# os.makedirs(DATA_DIR, exist_ok=True)

# # Load API key
# load_dotenv()
# groq_api_key = os.environ.get("GROQ_API_KEY")


# # ------------------ HELPERS ------------------ #
# def get_pdf_hash(file_bytes):
#     return hashlib.sha256(file_bytes).hexdigest()

# def save_processed_data(pdf_hash, index, chunks):
#     faiss.write_index(index, os.path.join(DATA_DIR, f"{pdf_hash}.faiss"))
#     with open(os.path.join(DATA_DIR, f"{pdf_hash}.json"), 'w') as f:
#         json.dump(chunks, f)

# def load_processed_data(pdf_hash):
#     idx_file = os.path.join(DATA_DIR, f"{pdf_hash}.faiss")
#     chk_file = os.path.join(DATA_DIR, f"{pdf_hash}.json")
#     if os.path.exists(idx_file) and os.path.exists(chk_file):
#         index = faiss.read_index(idx_file)
#         with open(chk_file, 'r') as f:
#             chunks = json.load(f)
#         return index, chunks
#     return None, None

# def load_pdf(file_bytes):
#     reader = PdfReader(BytesIO(file_bytes))
#     return "".join([page.extract_text() for page in reader.pages])

# def process_pdf(text):
#     text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
#     chunks = text_splitter.split_text(text)
#     embedding_model = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
#     embeddings = embedding_model.embed_documents(chunks)
#     index = faiss.IndexFlatL2(len(embeddings[0]))
#     index.add(np.array(embeddings).astype("float32"))
#     return index, chunks

# def faiss_retriever(question, index, chunks):
#     embedding_model = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
#     q_emb = np.array([embedding_model.embed_query(question)]).astype("float32")
#     _, idxs = index.search(q_emb, k=5)
#     return [chunks[i] for i in idxs[0]]

# def chat_with_pdf(question, index, chunks, model):
#     relevant_chunks = faiss_retriever(question, index, chunks)
#     context = "\n\n".join(relevant_chunks)
#     prompt = PromptTemplate.from_template("""
#     You are a helpful assistant for answering from documents.
#     Only use the provided context. If answer not in context, reply:
#     "I could not find the answer in the provided document."

#     Context:
#     {context}

#     Question: {question}
#     """).format(context=context, question=question)

#     chat_groq = ChatGroq(groq_api_key=groq_api_key, model_name=model)
#     response = chat_groq.invoke(prompt)
#     return getattr(response, "content", str(response))


# # ------------------ APP ------------------ #
# st.title("Team WorkFlow & Responsibilities")

# # Load PDF once
# with open(PDF_PATH, "rb") as f:
#     file_bytes = f.read()

# pdf_hash = get_pdf_hash(file_bytes)
# index, chunks = load_processed_data(pdf_hash)

# if index is None or chunks is None:
#     st.write("Processing PDF in the background...")
#     text = load_pdf(file_bytes)
#     index, chunks = process_pdf(text)
#     save_processed_data(pdf_hash, index, chunks)
#     st.success("PDF processed! You can start chatting.")

# model = st.sidebar.selectbox("Groq Model", [ 'gemma2-9b-it'])
# question = st.text_input("💬 Ask something from the document:")

# if question:
#     st.write("Fetching answer...")
#     answer = chat_with_pdf(question, index, chunks, model)
#     st.markdown(f"**Answer:** {answer}")


import os
import faiss
import numpy as np
import streamlit as st
from io import BytesIO
from PyPDF2 import PdfReader
from dotenv import load_dotenv
import json
import hashlib
from langchain_groq import ChatGroq
from langchain.prompts import PromptTemplate
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.embeddings import HuggingFaceEmbeddings

# ------------------ CONFIG ------------------ #
PDF_PATH = "sample_docs/Team_Workflow_Responsbilities.pdf"  # Update path
DATA_DIR = "processed_data"
os.makedirs(DATA_DIR, exist_ok=True)

# Load API key
load_dotenv()
groq_api_key = os.environ.get("GROQ_API_KEY")

# ------------------ HELPERS ------------------ #
def get_pdf_hash(file_bytes):
    return hashlib.sha256(file_bytes).hexdigest()

def save_processed_data(pdf_hash, index, chunks):
    faiss.write_index(index, os.path.join(DATA_DIR, f"{pdf_hash}.faiss"))
    with open(os.path.join(DATA_DIR, f"{pdf_hash}.json"), 'w') as f:
        json.dump(chunks, f)

def load_processed_data(pdf_hash):
    idx_file = os.path.join(DATA_DIR, f"{pdf_hash}.faiss")
    chk_file = os.path.join(DATA_DIR, f"{pdf_hash}.json")
    if os.path.exists(idx_file) and os.path.exists(chk_file):
        index = faiss.read_index(idx_file)
        with open(chk_file, 'r') as f:
            chunks = json.load(f)
        return index, chunks
    return None, None

def load_pdf(file_bytes):
    reader = PdfReader(BytesIO(file_bytes))
    return "".join([page.extract_text() for page in reader.pages])

def process_pdf(text):
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    chunks = text_splitter.split_text(text)
    embedding_model = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
    embeddings = embedding_model.embed_documents(chunks)
    index = faiss.IndexFlatL2(len(embeddings[0]))
    index.add(np.array(embeddings).astype("float32"))
    return index, chunks

def faiss_retriever(question, index, chunks):
    embedding_model = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
    q_emb = np.array([embedding_model.embed_query(question)]).astype("float32")
    _, idxs = index.search(q_emb, k=5)
    return [chunks[i] for i in idxs[0]]

def chat_with_pdf(question, index, chunks, model):
    relevant_chunks = faiss_retriever(question, index, chunks)
    context = "\n\n".join(relevant_chunks)
    prompt = PromptTemplate.from_template("""
    You are a helpful assistant for answering from documents.
    Only use the provided context. If answer not in context, reply:
    "I could not find the answer in the provided document."

    Context:
    {context}

    Question: {question}
    """).format(context=context, question=question)

    chat_groq = ChatGroq(groq_api_key=groq_api_key, model_name=model)
    response = chat_groq.invoke(prompt)
    return getattr(response, "content", str(response))

# ------------------ APP ------------------ #
st.title("📄 Team Workflow Document")

# Load PDF once
with open(PDF_PATH, "rb") as f:
    file_bytes = f.read()

pdf_hash = get_pdf_hash(file_bytes)
index, chunks = load_processed_data(pdf_hash)

if index is None or chunks is None:
    st.write("Processing PDF...")
    text = load_pdf(file_bytes)
    index, chunks = process_pdf(text)
    save_processed_data(pdf_hash, index, chunks)
    st.success("PDF processed! You can start chatting.")

# Initialize session state for chat
if "messages" not in st.session_state:
    st.session_state.messages = []

# Sidebar for model choice
model = 'gemma2-9b-it'

# Chat messages display
chat_container = st.container()
with chat_container:
    for msg in st.session_state.messages:
        role = "🧑 You" if msg["role"] == "user" else "🤖 Bot"
        st.markdown(f"**{role}:** {msg['content']}")

# Chat input at bottom
if question := st.chat_input("Type your question..."):
    st.session_state.messages.append({"role": "user", "content": question})
    answer = chat_with_pdf(question, index, chunks, model)
    st.session_state.messages.append({"role": "assistant", "content": answer})
    st.rerun()
