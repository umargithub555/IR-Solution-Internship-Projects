import os
import faiss
import numpy as np
import streamlit as st
from io import BytesIO
from PyPDF2 import PdfReader
from dotenv import load_dotenv
from langchain.chains import ConversationChain
from langchain.chains.conversation.memory import ConversationBufferMemory
from langchain_groq import ChatGroq
from langchain.prompts import PromptTemplate
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.embeddings import HuggingFaceEmbeddings

# Load API key from environment
load_dotenv()
groq_api_key = os.environ.get("GROQ_API_KEY")

# Function to load and extract text from PDF
def load_pdf(uploaded_file):
    pdf_bytes = uploaded_file.read()
    pdf_file = BytesIO(pdf_bytes)
    reader = PdfReader(pdf_file)
    text = "".join([page.extract_text() for page in reader.pages])
    return text

# Function to process the PDF, split text, and create embeddings
def process_pdf(text):
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    chunks = text_splitter.split_text(text)

    embedding_model = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
    embeddings = embedding_model.embed_documents(chunks)
    
    embedding_matrix = np.array(embeddings).astype("float32")
    
    dim = embedding_matrix.shape[1]
    index = faiss.IndexFlatL2(dim)
    index.add(embedding_matrix)
    
    return index, chunks

# Function to retrieve relevant chunks using FAISS
def faiss_retriever(question, index, chunks):
    embedding_model = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
    question_embedding = np.array([embedding_model.embed_query(question)]).astype("float32")
    
    _, indices = index.search(question_embedding, k=5)
    return [chunks[i] for i in indices[0]]

# Function to chat with PDF using Groq API
def chat_with_pdf(question, index, chunks, model):
    relevant_chunks = faiss_retriever(question, index, chunks)
    context = "\n\n".join(relevant_chunks)

    # prompt_template = PromptTemplate.from_template("""
    # Use the following context to answer the question. If the answer is not available in the context, provide a response based on your knowledge.
    
    # Context:
    # {context}
    
    # Question: {question}
    # """)
    prompt_template = PromptTemplate.from_template("""
    You are a helpful assistant for question answering from documents.
    Only answer using the information provided in the context.
    If the answer is not explicitly contained in the context, respond with:
    "I could not find the answer in the provided document."

    Context:
    {context}

    Question: {question}

    """)


    prompt = prompt_template.format(context=context, question=question)
    
    chat_groq = ChatGroq(groq_api_key=groq_api_key, model_name=model)
    response = chat_groq.invoke(prompt)

    return response.content if hasattr(response, "content") else str(response)

# Streamlit UI
st.title("PDF Chatbot with Groq & FAISS")

uploaded_file = st.file_uploader("Upload a PDF", type="pdf")

if uploaded_file:
    st.write("Processing PDF...")
    text = load_pdf(uploaded_file)
    index, chunks = process_pdf(text)
    st.write("PDF processed! You can now ask questions.")

    model = st.sidebar.selectbox("Select Groq Model", ['qwen/qwen3-32b', 'gemma2-9b-it','llama-3.1-8b-instant'])
    question = st.text_input("Ask a question about the PDF:")

    if question:
        st.write("Fetching answer...")
        response = chat_with_pdf(question, index, chunks, model)
        st.write("Answer:", response)

else:
    st.write("Upload a PDF to begin!")
