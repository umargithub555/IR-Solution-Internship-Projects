import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
import io





def visualize_numerical_columns(df, numeric_cols):
    numeric_plots = {}

    if df is not None:
        try:
            for col in numeric_cols:
                fig, axs = plt.subplots(1, 2, figsize=(12, 4))

                # Histogram
                sns.histplot(df[col], kde=True, ax=axs[0])
                axs[0].set_title(f'Distribution of {col}')

                # Boxplot
                sns.boxplot(x=df[col], ax=axs[1])
                axs[1].set_title(f'Boxplot of {col}')

                # Save plot figure in memory
                buf = io.BytesIO()
                fig.savefig(buf, format="png")
                buf.seek(0)
                numeric_plots[col] = buf  # Dictionary of buffers

                plt.close(fig)  # Avoid showing in non-interactive environments

        except Exception as e:
            print(f"An error occurred in [utils/visualization.py - visualize_numerical_column] - {e}")

    return numeric_plots



def visualize_categorical_columns(df, numeric_cols):
    categoric_plots = {}

    if df is not None:
        try:
            for col in numeric_cols:
                fig, axs = plt.subplots(1, 2, figsize=(12, 4))

                # Histogram
                sns.countplot(df[col], ax=axs[0])
                axs[0].set_title(f'Count Plot of {col}')

                # # Boxplot
                # sns.(x=df[col], ax=axs[1])
                # axs[1].set_title(f'Bar Plot of {col}')

                # Save plot figure in memory
                buf = io.BytesIO()
                fig.savefig(buf, format="png")
                buf.seek(0)
                categoric_plots[col] = buf  # Dictionary of buffers

                plt.close(fig)  # Avoid showing in non-interactive environments

        except Exception as e:
            print(f"An error occurred in [utils/visualization.py - visualize_categoric_column] - {e}")

    return categoric_plots



def correlation(df, numeric_cols):
    correlation_heatmap = {}

    if df is not None and numeric_cols is not None and len(numeric_cols) > 1:
        try:
            fig, ax = plt.subplots(figsize=(10, 6))
            correlation_matrix = df[numeric_cols].corr()
            sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', ax=ax)
            ax.set_title('Correlation Heatmap')

            buf = io.BytesIO()
            fig.savefig(buf, format="png")
            buf.seek(0)

            correlation_heatmap['img'] = buf
            correlation_heatmap['corr_matrix'] = correlation_matrix

            plt.close(fig)

        except Exception as e:
            print(f"An error occurred in [utils/visualization.py - correlation] - {e}")

    return correlation_heatmap



def multivariate_visualizations(df, col1, col2):
    """
    Create visualizations for relationships between two columns
    
    Args:
        df: DataFrame
        col1: First column name
        col2: Second column name
    
    Returns:
        dict: Dictionary with plot type as key and BytesIO buffer as value
    """
    multivariate_plots = {}
    
    if df is not None and col1 is not None and col2 is not None:
        try:
            # Check column types
            col1_numeric = df[col1].dtype in ['int64', 'float64']
            col2_numeric = df[col2].dtype in ['int64', 'float64']
            
            # Numerical vs Numerical
            if col1_numeric and col2_numeric:
                # Scatter Plot
                fig, ax = plt.subplots(figsize=(10, 6))
                sns.scatterplot(data=df, x=col1, y=col2, alpha=0.6, ax=ax)
                ax.set_title(f'Scatter Plot: {col1} vs {col2}')
                ax.set_xlabel(col1)
                ax.set_ylabel(col2)
                
                # Save scatter plot
                buf = io.BytesIO()
                fig.savefig(buf, format="png", bbox_inches='tight')
                buf.seek(0)
                multivariate_plots['scatter'] = buf
                plt.close(fig)
                
                # Regression Plot
                fig, ax = plt.subplots(figsize=(10, 6))
                sns.regplot(data=df, x=col1, y=col2, ax=ax, scatter_kws={'alpha':0.6})
                ax.set_title(f'Regression Plot: {col1} vs {col2}')
                ax.set_xlabel(col1)
                ax.set_ylabel(col2)
                
                # Save regression plot
                buf = io.BytesIO()
                fig.savefig(buf, format="png", bbox_inches='tight')
                buf.seek(0)
                multivariate_plots['regression'] = buf
                plt.close(fig)

        
            # Numerical vs Categorical
            elif (col1_numeric and not col2_numeric) or (not col1_numeric and col2_numeric):
                # Determine which is numerical and which is categorical
                if col1_numeric:
                    num_col, cat_col = col1, col2
                else:
                    num_col, cat_col = col2, col1
                
                # Box Plot
                fig, ax = plt.subplots(figsize=(10, 6))
                sns.boxplot(data=df, x=cat_col, y=num_col, ax=ax)
                ax.set_title(f'Box Plot: {num_col} by {cat_col}')
                ax.set_xlabel(cat_col)
                ax.set_ylabel(num_col)
                plt.xticks(rotation=45)
                
                # Save box plot
                buf = io.BytesIO()
                fig.savefig(buf, format="png", bbox_inches='tight')
                buf.seek(0)
                multivariate_plots['boxplot'] = buf
                plt.close(fig)
                
                # Violin Plot
                fig, ax = plt.subplots(figsize=(10, 6))
                sns.violinplot(data=df, x=cat_col, y=num_col, ax=ax)
                ax.set_title(f'Violin Plot: {num_col} by {cat_col}')
                ax.set_xlabel(cat_col)
                ax.set_ylabel(num_col)
                plt.xticks(rotation=45)
                
                # Save violin plot
                buf = io.BytesIO()
                fig.savefig(buf, format="png", bbox_inches='tight')
                buf.seek(0)
                multivariate_plots['violin'] = buf
                plt.close(fig)
                
                # Bar Plot (mean values)
                fig, ax = plt.subplots(figsize=(10, 6))
                sns.barplot(data=df, x=cat_col, y=num_col, ax=ax, ci=95)
                ax.set_title(f'Mean {num_col} by {cat_col}')
                ax.set_xlabel(cat_col)
                ax.set_ylabel(f'Mean {num_col}')
                plt.xticks(rotation=45)
                
                # Save bar plot
                buf = io.BytesIO()
                fig.savefig(buf, format="png", bbox_inches='tight')
                buf.seek(0)
                multivariate_plots['barplot'] = buf
                plt.close(fig)
            
            # Categorical vs Categorical
            else:
                # Stacked Bar Chart
                fig, ax = plt.subplots(figsize=(10, 6))
                crosstab = pd.crosstab(df[col1], df[col2])
                crosstab.plot(kind='bar', stacked=True, ax=ax)
                ax.set_title(f'Stacked Bar Chart: {col1} vs {col2}')
                ax.set_xlabel(col1)
                ax.set_ylabel('Count')
                plt.xticks(rotation=45)
                plt.legend(title=col2, bbox_to_anchor=(1.05, 1), loc='upper left')
                
                # Save stacked bar chart
                buf = io.BytesIO()
                fig.savefig(buf, format="png", bbox_inches='tight')
                buf.seek(0)
                multivariate_plots['stacked_bar'] = buf
                plt.close(fig)
                
                # Heatmap
                fig, ax = plt.subplots(figsize=(10, 6))
                sns.heatmap(crosstab, annot=True, fmt='d', cmap='Blues', ax=ax)
                ax.set_title(f'Heatmap: {col1} vs {col2}')
                ax.set_xlabel(col2)
                ax.set_ylabel(col1)
                
                # Save heatmap
                buf = io.BytesIO()
                fig.savefig(buf, format="png", bbox_inches='tight')
                buf.seek(0)
                multivariate_plots['heatmap'] = buf
                plt.close(fig)
                
        except Exception as e:
            print(f"An error occurred [utils/visualization.py - multivariate_visualizations] - {e}")
            
    else:
        print("df, col1, or col2 is missing")
    # for item,index in multivariate_plots.items():
    #    print(item,index)
    
    return multivariate_plots