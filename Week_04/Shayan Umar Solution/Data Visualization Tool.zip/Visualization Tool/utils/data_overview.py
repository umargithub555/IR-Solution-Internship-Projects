import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np




def display_data_overview(df):
    overview = {}

    if df is not None:
        try:
            overview['shape'] = df.shape

            overview['col-names'] = df.columns
            
            overview['info'] = df.info()

            overview['describe'] = df.describe()



            overview['null-count'] = df.isnull().sum()

            overview['duplicated-count'] = df.duplicated().sum()


            return overview
            
        except Exception as e:
            print(f"An error occur [utils/data_overview - display_data_overview] - {e}")
        



def seperate_column_types(df):
    all_columns = {}
    if df is not None:
        try:
            numerical_cols = [col for col in df.columns if df[col].dtype != 'object' ]

            categorical_cols = [col for col in df.columns if df[col].dtype == 'object']

            all_columns['numeric'] = numerical_cols

            all_columns['categoric'] = categorical_cols


            return all_columns

        except Exception as e:
            print(f"An error occur [utils/data_overview - display_data_overview] - {e}")
    else:
        print("df is not provided")
        return None