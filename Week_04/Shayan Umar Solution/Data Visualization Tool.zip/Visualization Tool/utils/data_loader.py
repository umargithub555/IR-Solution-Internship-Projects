import pandas as pd
import numpy as np



def handle_upload_file(uploaded_file):

    if uploaded_file is not None:
        try:
            if uploaded_file.name.endswith('.csv'):
                df = pd.read_csv(uploaded_file)
            elif uploaded_file.name.endswith('.xlsx'):
                df = pd.read_csv(uploaded_file)
            else:
                print("no file format matched")
                return None

            if df.empty:
                print("Dataframe is empty")
                return None

            return df    

        except Exception as e:
            print(f"An error occur file making dataframe [utils/data_loader.py] {e}")
    else:
        print("Please Upload a File")
        return None