import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
from data_overview import display_data_overview




def modify_data(df):

    df = df.dropna(inplace=True)

    pass