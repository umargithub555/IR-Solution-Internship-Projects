import streamlit as st
import io
from utils.data_loader import handle_upload_file
from utils.data_overview import display_data_overview, seperate_column_types
from utils.visualization import visualize_numerical_columns,visualize_categorical_columns,correlation,multivariate_visualizations
# from utils.filters import filter_dataframe
# from utils.helpers import render_download_button, error_handling

st.set_page_config(
    page_title="EDA Dashboard",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        padding: 2rem;
        border-radius: 10px;
        color: white;
        text-align: center;
        margin-bottom: 2rem;
    }
    
    .stButton > button {
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        border-radius: 8px;
        padding: 0.5rem 1rem;
        font-weight: 600;
        transition: all 0.3s ease;
    }
    
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
    }
    
    .metric-card {
        background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%) !important;
        padding: 1.5rem !important;
        border-radius: 12px !important;
        border-left: 5px solid #667eea !important;
        margin: 0.5rem 0 !important;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1) !important;
        border: 1px solid #dee2e6 !important;
    }
    
    .metric-card h4 {
        color: #495057 !important;
        margin-bottom: 1rem !important;
        font-size: 1.1rem !important;
        font-weight: 600 !important;
    }
    
    .metric-card p {
        color: #6c757d !important;
        margin: 0.5rem 0 !important;
        font-size: 0.95rem !important;
    }
    
    .metric-card strong {
        color: #495057 !important;
        font-weight: 600 !important;
    }
    
    .section-header {
        color: #667eea;
        font-size: 1.5rem;
        font-weight: 600;
        margin: 1rem 0;
        padding-bottom: 0.5rem;
        border-bottom: 2px solid #e9ecef;
    }
    
    .upload-zone {
        border: 2px dashed #667eea;
        border-radius: 10px;
        padding: 2rem;
        text-align: center;
        background: rgba(102, 126, 234, 0.05);
        margin: 1rem 0;
    }
    
    .analysis-section {
        background: gray;
        padding: 1.5rem;
        border-radius: 10px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)

# -------------------------
# HEADER SECTION
# -------------------------
st.markdown("""
<div class="main-header">
    <h1>📊 Exploratory Data Analysis Dashboard</h1>
    <p style="font-size: 1.1rem; margin-top: 1rem;">
        🚀 Unlock insights from your data with our interactive analysis tool
    </p>
</div>
""", unsafe_allow_html=True)

# -------------------------
# FILE UPLOAD SECTION
# -------------------------
st.sidebar.markdown("""
<div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
            padding: 1rem; border-radius: 10px; color: white; text-align: center; margin-bottom: 1rem;">
    <h3>📁 Data Upload Center</h3>
</div>
""", unsafe_allow_html=True)

uploaded_file = st.sidebar.file_uploader(
    "Choose your dataset", 
    type=["csv", "xls", "xlsx"],
    help="Upload CSV or Excel files to begin analysis"
)

df = handle_upload_file(uploaded_file)

# -------------------------
# MAIN WORKFLOW
# -------------------------
if df is not None:
    # Success message with custom styling
    st.markdown("""
    <div style="background: #d4edda; color: #155724; padding: 1rem; border-radius: 8px; border-left: 4px solid #28a745; margin: 1rem 0;">
        <strong>✅ Dataset loaded successfully!</strong> Ready for analysis.
    </div>
    """, unsafe_allow_html=True)
    
    # Display basic dataset info
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("📊 Rows", f"{df.shape[0]:,}")
    with col2:
        st.metric("📋 Columns", f"{df.shape[1]:,}")
    with col3:
        st.metric("💾 Size", f"{df.memory_usage(deep=True).sum() / 1024**2:.1f} MB")
    with col4:
        st.metric("🔍 Data Types", f"{df.dtypes.nunique()}")

    # Quick preview
    st.markdown('<div class="section-header">👀 Quick Data Preview</div>', unsafe_allow_html=True)
    st.dataframe(df.head(), use_container_width=True)

    # ---- DATASET OVERVIEW SECTION ----
    st.markdown('<div class="section-header">📌 Dataset Analysis Center</div>', unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns(3)
    with col1:
        show_overview = st.button("🔍 **Generate Dataset Overview**", use_container_width=True)
    with col2:
        show_numerical = st.button("📈 **Analyze Numerical Data**", use_container_width=True)
    with col3:
        show_categorical = st.button("🧩 **Analyze Categorical Data**", use_container_width=True)
    
    col4, col5 , col6 = st.columns(3)
    with col4:
        show_correlation = st.button("🔥 **Generate Correlation Matrix**", use_container_width=True)
    with col5:
        show_relationships = st.button("🔗 **Explore Relationships**", use_container_width=True)
    with col6:
        show_modification = st.button("🧩 **Modify Dataset**", use_container_width=True)

    # Initialize session state for controlling display
    if 'show_overview' not in st.session_state:
        st.session_state.show_overview = False
    if 'show_numerical' not in st.session_state:
        st.session_state.show_numerical = False
    if 'show_categorical' not in st.session_state:
        st.session_state.show_categorical = False
    if 'show_correlation' not in st.session_state:
        st.session_state.show_correlation = False

    if 'show_relationships' not in st.session_state:
        st.session_state.show_relationships = False

    if 'show_modification' not in st.session_state:
        st.session_state.show_modification = False


    # Update session state based on button clicks
    if show_overview:
        st.session_state.show_overview = True
    if show_numerical:
        st.session_state.show_numerical = True
    if show_categorical:
        st.session_state.show_categorical = True
    if show_correlation:
        st.session_state.show_correlation = True
    if show_relationships:
        st.session_state.show_relationships = True
    if show_modification:
        st.session_state.show_modification = True


    # Get column types for later use
    col_type = seperate_column_types(df)
    numeric_cols = col_type['numeric']
    categorical_cols = col_type['categoric']

    # ---- DATASET OVERVIEW ----
    if st.session_state.show_overview:
        with st.container():
            st.markdown('<div class="analysis-section">', unsafe_allow_html=True)
            st.markdown("### 🔍 Comprehensive Dataset Overview")
            
            with st.spinner("Generating comprehensive analysis..."):
                overview = display_data_overview(df)
                
                # Basic Information
                st.markdown("#### 📊 Dataset Dimensions")
                rows = overview['shape'][0]
                columns = overview['shape'][1]
                
                info_col1, info_col2 = st.columns(2)
                with info_col1:
                    st.markdown(f"""
                    <div class="metric-card">
                        <h4>📏 Dataset Size</h4>
                        <p><strong>Rows:</strong> {rows:,}</p>
                        <p><strong>Columns:</strong> {columns:,}</p>
                    </div>
                    """, unsafe_allow_html=True)
                
                with info_col2:
                    st.markdown(f"""
                    <div class="metric-card">
                        <h4>🔄 Data Quality</h4>
                        <p><strong>Duplicates:</strong> {overview['duplicated-count']:,}</p>
                        <p><strong>Duplicate %:</strong> {(overview['duplicated-count']/rows*100):.1f}%</p>
                    </div>
                    """, unsafe_allow_html=True)

                # Column Information
                st.markdown("#### 📋 Column Details")
                columns_names = overview['col-names']
                
                col_info_col1, col_info_col2 = st.columns(2)
                with col_info_col1:
                    st.markdown("**🔢 Numeric Columns**")
                    if numeric_cols:
                        st.write(numeric_cols)
                    else:
                        st.info("No numeric columns found")
                
                with col_info_col2:
                    st.markdown("**📝 Categorical Columns**")
                    if categorical_cols:
                        st.write(categorical_cols)
                    else:
                        st.info("No categorical columns found")

                # Technical Information
                with st.expander("🔧 Technical Information", expanded=False):
                    buffer = io.StringIO()
                    df.info(buf=buffer)
                    info_str = buffer.getvalue()
                    st.text(info_str)

                # Statistical Summary
                st.markdown("#### 📈 Statistical Summary")
                describe_stats = overview['describe']
                if not describe_stats.empty:
                    st.dataframe(describe_stats, use_container_width=True)
                else:
                    st.info("No numerical columns available for statistical summary")
            
            st.markdown('</div>', unsafe_allow_html=True)

    # ---- NUMERICAL ANALYSIS ----
    if st.session_state.show_numerical:
        with st.container():
            st.markdown('<div class="analysis-section">', unsafe_allow_html=True)
            st.markdown("### 📈 Numerical Column Analysis")
            
            if numeric_cols:
                with st.spinner("Creating numerical visualizations..."):
                    num_plots = visualize_numerical_columns(df, numeric_cols)
                    
                    if num_plots:
                        for i, (col, img_buf) in enumerate(num_plots.items()):
                            st.markdown(f"#### 📊 {col}")
                            st.image(img_buf, use_container_width=True)
                            if i < len(num_plots) - 1:
                                st.divider()
                    else:
                        st.warning("No plots generated for numerical columns")
            else:
                st.info("📋 No numerical columns found in the dataset")
            
            st.markdown('</div>', unsafe_allow_html=True)

    # ---- CATEGORICAL ANALYSIS ----
    if st.session_state.show_categorical:
        with st.container():
            st.markdown('<div class="analysis-section">', unsafe_allow_html=True)
            st.markdown("### 🧩 Categorical Column Analysis")
            
            if categorical_cols:
                with st.spinner("Creating categorical visualizations..."):
                    cat_plots = visualize_categorical_columns(df, categorical_cols)
                    
                    if cat_plots:
                        for i, (col, img_buf) in enumerate(cat_plots.items()):
                            st.markdown(f"#### 📋 {col}")
                            st.image(img_buf, use_container_width=True)
                            if i < len(cat_plots) - 1:
                                st.divider()
                    else:
                        st.warning("No plots generated for categorical columns")
            else:
                st.info("📝 No categorical columns found in the dataset")
            
            st.markdown('</div>', unsafe_allow_html=True)

    # ---- CORRELATION HEATMAP ----
    if st.session_state.show_correlation:
        with st.container():
            st.markdown('<div class="analysis-section">', unsafe_allow_html=True)
            st.markdown("### 🔥 Correlation Analysis")
            
            if len(numeric_cols) > 1:
                with st.spinner("Generating correlation matrix..."):
                    corr_data = correlation(df, numeric_cols)
                    
                    if corr_data:
                        st.markdown("#### 🎯 Correlation Heatmap")
                        st.image(corr_data['img'], caption="Correlation Heatmap", use_container_width=True)
                        
                        st.markdown("#### 📊 Correlation Matrix")
                        st.dataframe(corr_data['corr_matrix'].round(3), use_container_width=True)
                        
                        # Highlight strong correlations
                        corr_matrix = corr_data['corr_matrix']
                        strong_corr = []
                        for i in range(len(corr_matrix.columns)):
                            for j in range(i+1, len(corr_matrix.columns)):
                                corr_val = corr_matrix.iloc[i, j]
                                if abs(corr_val) > 0.7:
                                    strong_corr.append((corr_matrix.columns[i], corr_matrix.columns[j], corr_val))
                        
                        if strong_corr:
                            st.markdown("#### ⚡ Strong Correlations (|r| > 0.7)")
                            for col1, col2, corr_val in strong_corr:
                                correlation_type = "Positive" if corr_val > 0 else "Negative"
                                st.markdown(f"- **{col1}** ↔ **{col2}**: {corr_val:.3f} ({correlation_type})")
                    else:
                        st.warning("Could not generate correlation analysis")
            else:
                st.info("🔢 Need at least 2 numerical columns for correlation analysis")
            
            st.markdown('</div>', unsafe_allow_html=True)

    # ---- RELATIONSHIP VISUALIZATION ----
    # if st.session_state.show_relationships:
    #     choice = ['numerical','categorical']
    #     choosed = None
    #     with st.container():
    #         st.markdown('<div class="analysis-section">', unsafe_allow_html=True)
    #         st.markdown("### 🔗 Relationship Analysis")
    #         st.info("🚧 Advanced relationship analysis coming soon! This will include scatter plots, pair plots, and interactive visualizations.")

    #         tab1, tab2, tab3 = st.tabs(["📊 Numerical vs Numerical", "📈 Numerical vs Categorical", "🧩 Categorical vs Categorical"])
            
    #         with tab1:
    #             st.markdown("#### 📊 Numerical vs Numerical Relationships")
    #             if len(numeric_cols) >= 2:
    #                 col1, col2 = st.columns(2)
    #                 if choosed == choice[0]:
    #                     with col1:
    #                         x_numeric = st.selectbox("Select X-axis (Numerical)", numeric_cols, key="x_num_num")
    #                     with col2:
    #                         y_numeric = st.selectbox("Select Y-axis (Numerical)", [col for col in numeric_cols if col != x_numeric], key="y_num_num")
                        
    #                     multivariate_plots = multivariate_visualizations(df, x_numeric,y_numeric)
    #                 elif choosed == choice[1]:
    #                      with col1:
    #                         x_numeric = st.selectbox("Select X-axis (Numerical)", numeric_cols, key="x_num_cat")
    #                      with col2:
    #                         y_categoric = st.selectbox("Select Y-axis (Categorical)", [col for col in categorical_cols], key="y_num_num")

    #                      multivariate_plots = multivariate_visualizations(df, x_numeric,y_categoric)
    #                 else:
    #                     st.error("Choose a valid category")
                        
                

    #             if multivariate_plots:
    #                 st.markdown("#### 🎯 Multivariate Plots - [SCATTER]")
    #                 st.image(multivariate_plots['scatter'], caption="multivariate plots", use_container_width=True)
                        
    #                 st.markdown("#### 🎯 Multivariate Plots - [REGRESSION]")
    #                 st.image(multivariate_plots['regression'], caption="multivariate plots", use_container_width=True)
                        

    #         st.markdown('</div>', unsafe_allow_html=True)


    if st.session_state.show_relationships:
        with st.container():
            st.markdown('<div class="analysis-section">', unsafe_allow_html=True)
            st.markdown("### 🔗 Relationship Analysis")
            st.info("🚧 Advanced relationship analysis coming soon!")

            tab1, tab2, tab3 = st.tabs(["📊 Numerical vs Numerical", "📈 Numerical vs Categorical", "🧩 Categorical vs Categorical"])

            with tab1:
                st.markdown("#### 📊 Numerical vs Numerical Relationships")
                choice = ['Numerical vs Numerical', 'Numerical vs Categorical']
                choosed = st.selectbox("Select Relationship Type", choice, key="relationship_type")

                multivariate_plots = None  # initialize

                if choosed == choice[0] and len(numeric_cols) >= 2:
                    col1, col2 = st.columns(2)
                    with col1:
                        x_numeric = st.selectbox("Select X-axis (Numerical)", numeric_cols, key="x_num_num")
                    with col2:
                        y_numeric = st.selectbox("Select Y-axis (Numerical)", [col for col in numeric_cols if col != x_numeric], key="y_num_num")
                    multivariate_plots = multivariate_visualizations(df, x_numeric, y_numeric)

                elif choosed == choice[1] and numeric_cols and categorical_cols:
                    col1, col2 = st.columns(2)
                    with col1:
                        x_numeric = st.selectbox("Select X-axis (Numerical)", numeric_cols, key="x_num_cat")
                    with col2:
                        y_categoric = st.selectbox("Select Y-axis (Categorical)", categorical_cols, key="y_cat_cat")
                    multivariate_plots = multivariate_visualizations(df, x_numeric, y_categoric)

                if multivariate_plots and choosed == choice[0]:
                    st.markdown("#### 🎯 Multivariate Plots - [SCATTER]")
                    st.image(multivariate_plots['scatter'], use_container_width=True)

                    st.markdown("#### 🎯 Multivariate Plots - [REGRESSION]")
                    st.image(multivariate_plots['regression'], use_container_width=True)
                
                elif multivariate_plots and choosed == choice[1]:
                    st.markdown("#### 🎯 Multivariate Plots - [BOX PLOT]")
                    st.image(multivariate_plots['boxplot'], use_container_width=True)

                    st.markdown("#### 🎯 Multivariate Plots - [VIOLIN PLOT]")
                    st.image(multivariate_plots['violin'], use_container_width=True)

                    st.markdown("#### 🎯 Multivariate Plots - [BAR PLOT]")
                    st.image(multivariate_plots['barplot'], use_container_width=True)


            st.markdown('</div>', unsafe_allow_html=True)

    if st.session_state.show_modification:
        with st.container():
            st.markdown('<div class="analysis-section">', unsafe_allow_html=True)
            st.markdown("### 🧩 Modify Dataset")

            drop_nulls = st.button("Drop Null values")
            rows = df.shape[0]
            columns = df.shape[1]
            
            missing_count = df.isnull().sum().sum()
            if missing_count > 0:
                st.warning(f"⚠️ Found {missing_count:,} missing values. Total dataset shape {rows} * {columns}")
            else:
                st.info("✅ No missing values found.")

            if drop_nulls:
                df = df.dropna()
                st.success("✅ Dropping NaN values : Rows with missing values dropped.")
                rows = df.shape[0]
                columns = df.shape[1]
                st.success(f"Number of rows and columns after dropping NaNs Rows :{rows} * {columns} Columns" )
                st.dataframe(df.head())
            
            
            # rows = overview['shape'][0]
            # columns = overview['shape'][1]

            
            
            st.markdown('</div>', unsafe_allow_html=True)

    # ---- FILTER SECTION ----
    st.sidebar.markdown("---")
    st.sidebar.markdown("### 🔧 Data Filters")
    with st.sidebar.expander("Apply Filters", expanded=False):
        st.info("🚧 Interactive filtering options coming soon!")
        # Placeholder: Call filter_dataframe(df)
        # filtered_df = filter_dataframe(df)
        # Use filtered_df going forward

    # ---- DOWNLOAD SECTION ----
    st.sidebar.markdown("---")
    st.sidebar.markdown("### ⬇️ Export Options")
    with st.sidebar.expander("Download Results", expanded=False):
        st.info("🚧 Export functionality coming soon!")
        # Placeholder: Call render_download_button(df or filtered_df)
        # render_download_button(df)

    # Reset buttons section
    st.sidebar.markdown("---")
    if st.sidebar.button("🔄 **Reset All Analysis**", use_container_width=True):
        st.session_state.show_overview = False
        st.session_state.show_numerical = False
        st.session_state.show_categorical = False
        st.session_state.show_correlation = False
        st.session_state.show_relationships = False
        st.rerun()

else:
    # Enhanced empty state
    st.markdown("""
    <div class="upload-zone">
        <h3>🎯 Ready to Explore Your Data?</h3>
        <p style="font-size: 1.1rem; color: #6c757d; margin: 1rem 0;">
            Upload your CSV or Excel file to get started with comprehensive data analysis
        </p>
        <div style="margin: 1rem 0;">
            <p><strong>Supported formats:</strong> CSV, XLS, XLSX</p>
            <p><strong>Features available:</strong> Statistical analysis, Visualizations, Correlations</p>
        </div>
    </div>
    """, unsafe_allow_html=True)
    
    # Add some example benefits
    st.markdown("### 🌟 What You'll Get")
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("""
        **📊 Data Overview**
        - Dataset dimensions
        - Column types
        - Missing values
        - Statistical summary
        """)
    
    with col2:
        st.markdown("""
        **📈 Visualizations**  
        - Distribution plots
        - Box plots
        - Category analysis
        - Correlation heatmaps
        """)
    
    with col3:
        st.markdown("""
        **🔍 Insights**
        - Data quality assessment
        - Pattern detection
        - Relationship analysis
        - Export capabilities
        """)
































# # app.py

# import streamlit as st
# import io
# from utils.data_loader import handle_upload_file
# from utils.data_overview import display_data_overview, seperate_column_types
# from utils.visualization import visualize_numerical_columns,visualize_categorical_columns,correlation
# # from utils.filters import filter_dataframe
# # from utils.helpers import render_download_button, error_handling

# # -------------------------
# # PAGE CONFIGURATION
# # -------------------------
# st.set_page_config(
#     page_title="EDA Dashboard",
#     layout="wide",
#     initial_sidebar_state="expanded"
# )

# # -------------------------
# # HEADER SECTION
# # -------------------------
# st.title("📊 Exploratory Data Analysis Dashboard")
# st.markdown(
#     """
#     Welcome to the interactive EDA tool. Upload your dataset and start exploring it visually and statistically.
#     """
# )

# st.divider()

# # -------------------------
# # FILE UPLOAD SECTION
# # -------------------------
# st.sidebar.header("📁 Upload Dataset")
# uploaded_file = st.sidebar.file_uploader("Choose a CSV or Excel file", type=["csv", "xls", "xlsx"])

# df = handle_upload_file(uploaded_file)

# # -------------------------
# # MAIN WORKFLOW
# # -------------------------
# if df is not None:
#     st.success("✅ File successfully loaded!")

#     # ---- OVERVIEW ----
#     with st.expander("📌 Dataset Overview", expanded=True):
#         st.subheader("🔍 Basic Information")
#         # Placeholder: Call display_data_overview(df)
#         st.dataframe(df.head())

#         overview = display_data_overview(df)
#         rows = overview['shape'][0]
#         columns = overview['shape'][1]
#         st.markdown(f"Number of Rows and Columns in the dataset -> Rows - {rows} *  Columns -> {columns}")

#         columns_names = overview['col-names']

#         st.markdown("**Columns**")
#         st.write(columns_names)

        
#         buffer = io.StringIO()
#         df.info(buf=buffer)
#         info_str = buffer.getvalue()
#         st.markdown("**ℹ️ Info:**")
#         st.text(info_str)

#         # info = overview['info']
#         # st.markdown("**Higher Level Info About the Dataset**")
#         # st.write(info)


#         describe_stats = overview['describe']
#         st.markdown("**Statistical Analsis about Numerical Columns**")
#         st.dataframe(describe_stats)

#         st.markdown(f"**📂 Duplicated Rows:** {overview['duplicated-count']}")


#     # ---- COLUMN TYPE SEPARATION ----
#         col_type = seperate_column_types(df)
#         numeric_cols = col_type['numeric']
#         categorical_cols = col_type['categoric']

#         # st.subheader("📊 Column Types")

#         st.markdown("**Numeric Columns**")
#         st.write(numeric_cols)  # Shows as a list

#         st.markdown("**Categorical Columns**")
#         st.write(categorical_cols)


#     # ---- FILTER SECTION ----
#     with st.sidebar.expander("🔧 Apply Filters"):
#         # Placeholder: Call filter_dataframe(df)
#         # filtered_df = filter_dataframe(df)
#         # Use filtered_df going forward
#         pass

#     # ---- NUMERICAL ANALYSIS ----
#     with st.expander("📌 Numerical Columns Plots", expanded=True):
#         st.subheader("📈 Numerical Column Analysis")
#         # selected_num_col = st.selectbox("Select a numerical column", numeric_cols)
#         num_plots = visualize_numerical_columns(df,numeric_cols)

#         if num_plots:
#             for col, img_buf in num_plots.items():
#                 st.markdown(f"### {col}")
#                 st.image(img_buf, use_container_width=True)
#         #

#     # ---- CATEGORICAL ANALYSIS ----
#     with st.expander("📌 Categorical Columns Plots", expanded=True):
#         st.subheader("🧩 Categorical Column Analysis")
#         # selected_cat_col = st.selectbox("Select a categorical column", categorical_cols)

#         cat_plots = visualize_categorical_columns(df,categorical_cols)

#         if cat_plots:
#             for col , img_buf in cat_plots.items():
#                 st.markdown(f"### {col}")
#                 st.image(img_buf, use_container_width=True)

#     # ---- RELATIONSHIP VISUALIZATION ----
#     st.subheader("🔗 Relationship Analysis")
#     col1, col2 = st.columns(2)
#     # with col1:
#     #     x_col = st.selectbox("Select X axis", numeric_cols + categorical_cols, key="x_axis")
#     # with col2:
#     #     y_col = st.selectbox("Select Y axis", numeric_cols, key="y_axis")

#     # if x_col and y_col:
#     #     # Placeholder: Call visualize_relationships(df, x_col, y_col)
#     #     pass

#     # ---- CORRELATION HEATMAP ----
#     with st.expander("📌 HeatMap ", expanded=True):
#         st.subheader("🔥 Correlation Heatmap")
        
#         if len(numeric_cols) > 1:
#             corr_data = correlation(df, numeric_cols)
            
#             if corr_data:
#                 st.image(corr_data['img'], caption="Correlation Heatmap", use_container_width=True)
#                 st.dataframe(corr_data['corr_matrix'].round(2))
#         else:
#             st.info("Not enough numerical columns for correlation matrix.")

#         # ---- DOWNLOAD SECTION ----
#         st.sidebar.header("⬇️ Download")
#         # Placeholder: Call render_download_button(df or filtered_df)
#         # render_download_button(df)

# else:
#     st.info("Awaiting file upload...")



# app.py

